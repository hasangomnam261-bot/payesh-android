package org.rayatalhoda.payesh;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.hardware.biometrics.BiometricPrompt;
import android.hardware.fingerprint.FingerprintManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.util.Base64;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.io.OutputStream;
import java.io.InputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONObject;

/** Fully offline Android shell. File downloads use Android's Storage Access Framework. */
public final class MainActivity extends Activity {
    private static final int REQUEST_OPEN_FILE = 4021;
    private static final int REQUEST_SAVE_FILE = 4022;
    private static final String PREFS = "payesh_android_settings";
    private static final String BIOMETRIC_USER = "biometric_username";
    private static final int MAX_EXPORT_BYTES = 24 * 1024 * 1024;

    private WebView webView;
    private ValueCallback<Uri[]> filePickerResult;
    private byte[] pendingFileBytes;
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(4 | 1024 | 4096);

        webView = new WebView(this);
        webView.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        webView.addJavascriptInterface(new PayeshBridge(), "PayeshAndroid");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return !url.startsWith("file:///android_asset/");
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view,
                    android.webkit.WebResourceRequest request) {
                return !request.getUrl().toString().startsWith("file:///android_asset/");
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                    FileChooserParams params) {
                if (filePickerResult != null) filePickerResult.onReceiveValue(null);
                filePickerResult = callback;
                try {
                    Intent intent = params.createIntent();
                    startActivityForResult(intent, REQUEST_OPEN_FILE);
                    return true;
                } catch (Exception ex) {
                    filePickerResult.onReceiveValue(null);
                    filePickerResult = null;
                    return false;
                }
            }
        });
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_OPEN_FILE) {
            if (filePickerResult != null) {
                Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
                filePickerResult.onReceiveValue(result);
                filePickerResult = null;
            }
            return;
        }
        if (requestCode == REQUEST_SAVE_FILE) {
            final byte[] bytes = pendingFileBytes;
            pendingFileBytes = null;
            if (resultCode != RESULT_OK || data == null || data.getData() == null) {
                nativeSaveCompleted(false, "ذخیره فایل لغو شد");
                return;
            }
            if (bytes == null) {
                nativeSaveCompleted(false, "اطلاعات فایل در دسترس نیست");
                return;
            }
            final Uri uri = data.getData();
            io.execute(() -> {
                try {
                    if (bytes.length == 0) throw new IllegalStateException("خروجی صفر بایت است");
                    // Do not acknowledge success until the stream has been closed.
                    try (OutputStream os = getContentResolver().openOutputStream(uri, "rwt")) {
                        if (os == null) throw new IllegalStateException("باز کردن مسیر ذخیره ممکن نشد");
                        os.write(bytes);
                        os.flush();
                    }
                    // Read the file back: some Android document providers may create
                    // an empty file even when opening the save dialog succeeded.
                    try (InputStream in = getContentResolver().openInputStream(uri)) {
                        if (in == null) throw new IllegalStateException("بازخوانی فایل ذخیره‌شده ممکن نشد");
                        byte[] buf = new byte[8192];
                        int total = 0;
                        int n;
                        while ((n = in.read(buf)) != -1) {
                            for (int i = 0; i < n; i++) {
                                if (total >= bytes.length || buf[i] != bytes[total])
                                    throw new IllegalStateException("محتوای فایل ذخیره‌شده با خروجی برابر نیست");
                                total++;
                            }
                        }
                        if (total != bytes.length)
                            throw new IllegalStateException("ذخیره ناقص است: " + total + " از " + bytes.length + " بایت");
                    }
                    nativeSaveCompleted(true, "فایل ذخیره و بررسی شد");
                } catch (Exception e) {
                    nativeSaveCompleted(false, "خطا در ذخیره یا بررسی فایل: " + e.getMessage());
                }
            });
        }
    }

    private void js(String expression) {
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(expression, null);
        });
    }
    private void nativeSaveCompleted(boolean ok, String message) {
        js("window.payeshNativeSaveComplete(" + ok + "," + JSONObject.quote(message) + ");");
    }
    private SharedPreferences prefs() { return getSharedPreferences(PREFS, MODE_PRIVATE); }

    private boolean hasBiometric() {
        if (Build.VERSION.SDK_INT < 28) return false;
        FingerprintManager manager = getSystemService(FingerprintManager.class);
        return manager != null && manager.isHardwareDetected() && manager.hasEnrolledFingerprints();
    }

    private void fingerprintPrompt() {
        if (!hasBiometric()) {
            js("window.payeshBiometricFailed('اثر انگشت روی گوشی تنظیم نشده است');");
            return;
        }
        final String username = prefs().getString(BIOMETRIC_USER, "");
        if (username == null || username.length() == 0) {
            js("window.payeshBiometricFailed('ابتدا یک بار با رمز وارد شوید');");
            return;
        }
        try {
            BiometricPrompt prompt = new BiometricPrompt.Builder(this)
                    .setTitle("ورود به پایش")
                    .setSubtitle("اثر انگشت خود را تأیید کنید")
                    .setNegativeButton("ورود با رمز", getMainExecutor(), (dialog, which) -> {})
                    .build();
            prompt.authenticate(new CancellationSignal(), getMainExecutor(),
                    new BiometricPrompt.AuthenticationCallback() {
                        @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                            super.onAuthenticationSucceeded(result);
                            js("window.payeshBiometricAuthenticated(" + JSONObject.quote(username) + ");");
                        }
                        @Override public void onAuthenticationError(int code, CharSequence error) {
                            super.onAuthenticationError(code, error);
                            if (code != BiometricPrompt.BIOMETRIC_ERROR_USER_CANCELED &&
                                code != BiometricPrompt.BIOMETRIC_ERROR_NEGATIVE_BUTTON)
                                js("window.payeshBiometricFailed(" + JSONObject.quote(error.toString()) + ");");
                        }
                    });
        } catch (Exception ex) {
            js("window.payeshBiometricFailed('سامانه اثر انگشت در دسترس نیست');");
        }
    }

    public final class PayeshBridge {
        @JavascriptInterface public void saveFile(String filename, String mime, String base64) {
            if (base64 == null || base64.length() > MAX_EXPORT_BYTES * 4 / 3 + 32) {
                nativeSaveCompleted(false, "حجم فایل بیش از حد مجاز است");
                return;
            }
            final byte[] decoded;
            try {
                decoded = Base64.decode(base64, Base64.DEFAULT);
            } catch (Exception e) {
                nativeSaveCompleted(false, "محتوای فایل معتبر نیست");
                return;
            }
            if (decoded.length == 0) {
                nativeSaveCompleted(false, "خروجی خالی است؛ هیچ فایلی ذخیره نشد");
                return;
            }
            if (decoded.length > MAX_EXPORT_BYTES) {
                nativeSaveCompleted(false, "حجم فایل بیش از ۲۴ مگابایت است");
                return;
            }
            final String safeName = filename == null ? "payesh-export.json" :
                    filename.replaceAll("[/\\\\\\r\\n]", "_").trim();
            final String safeMime = mime == null || mime.trim().isEmpty() ?
                    "application/octet-stream" : mime;
            runOnUiThread(() -> {
                if (pendingFileBytes != null) {
                    nativeSaveCompleted(false, "ابتدا ذخیره فایل قبلی را تمام کنید");
                    return;
                }
                pendingFileBytes = decoded;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(safeMime);
                intent.putExtra(Intent.EXTRA_TITLE, safeName.isEmpty() ? "payesh-export.json" : safeName);
                try { startActivityForResult(intent, REQUEST_SAVE_FILE); }
                catch (Exception ex) {
                    pendingFileBytes = null;
                    nativeSaveCompleted(false, "برنامه‌ای برای ذخیره فایل پیدا نشد");
                }
            });
        }
        @JavascriptInterface public boolean biometricAvailable() { return hasBiometric(); }
        @JavascriptInterface public String biometricAccount() {
            String name = prefs().getString(BIOMETRIC_USER, "");
            return name == null ? "" : name;
        }
        @JavascriptInterface public void enableBiometric(String username) {
            if (!hasBiometric() || username == null || username.trim().isEmpty()) return;
            prefs().edit().putString(BIOMETRIC_USER, username.trim()).apply();
        }
        @JavascriptInterface public void disableBiometric() {
            prefs().edit().remove(BIOMETRIC_USER).apply();
        }
        @JavascriptInterface public void requestBiometric() { runOnUiThread(() -> fingerprintPrompt()); }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        if (filePickerResult != null) { filePickerResult.onReceiveValue(null); filePickerResult = null; }
        io.shutdown();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
